Simple Node/Express backend. It stores leads to server/server/leads.json and exposes POST /api/leads.
To run backend: node server/server.js (or use npm start from project root).