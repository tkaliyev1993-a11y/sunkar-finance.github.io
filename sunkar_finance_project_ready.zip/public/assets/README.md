Place your real logo files here with these exact names:
- logo-dark.png  (gold-on-black version)
- logo-light.png (gold-on-dark-blue version)

Two small placeholder PNGs are included (logo-dark.png and logo-light.png). Replace them with your real logos when ready.
